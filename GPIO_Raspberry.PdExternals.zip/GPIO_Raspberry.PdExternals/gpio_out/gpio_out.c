#include "m_pd.h"
#include <stdlib.h>

static t_class *gpio_out_class;

typedef struct _gpio_out {
    t_object x_obj;
    int gpio_pin;
    int last_value;
} t_gpio_out;


// envia comanda a pigpiod via pigs
void gpio_out_float(t_gpio_out *x, t_floatarg f)
{
    int val = (f != 0);

    if (val == x->last_value)
        return;

    x->last_value = val;

    char cmd[64];
    sprintf(cmd, "pigs w %d %d", x->gpio_pin, val);
    system(cmd);
}


// constructor
void *gpio_out_new(t_symbol *s, int argc, t_atom *argv)
{
    t_gpio_out *x = (t_gpio_out *)pd_new(gpio_out_class);

    x->gpio_pin = (argc > 0) ? atom_getint(argv) : 17;
    x->last_value = -1;

    return (void *)x;
}


// setup
void gpio_out_setup(void)
{
    gpio_out_class = class_new(
        gensym("gpio_out"),
        (t_newmethod)gpio_out_new,
        0,
        sizeof(t_gpio_out),
        CLASS_DEFAULT,
        A_GIMME,
        0
    );

    class_addfloat(gpio_out_class, gpio_out_float);
}
