#include "m_pd.h"
#include <pigpiod_if2.h>

static t_class *gpio_in_class;

typedef struct _gpio_in {
    t_object x_obj;

    int pi;
    int gpio_pin;
    int last_value;

    t_outlet *out;
} t_gpio_in;


// READ (bang)
void gpio_in_bang(t_gpio_in *x)
{
    if (x == NULL) return;
    if (x->pi < 0) return;

    int val = gpio_read(x->pi, x->gpio_pin);

    if (val != x->last_value)
    {
        x->last_value = val;
        outlet_float(x->out, val);
    }
}


// CONSTRUCTOR
void *gpio_in_new(t_floatarg f)
{
    t_gpio_in *x = (t_gpio_in *)pd_new(gpio_in_class);

    x->gpio_pin = (int)f;
    x->pi = -1;
    x->last_value = 0;

    // connect to pigpiod daemon
    x->pi = pigpio_start(NULL, NULL);

    if (x->pi < 0)
    {
        post("gpio_in: ERROR connecting to pigpiod");
        return NULL;
    }

    set_mode(x->pi, x->gpio_pin, PI_INPUT);
    set_pull_up_down(x->pi, x->gpio_pin, PI_PUD_UP);

    x->last_value = gpio_read(x->pi, x->gpio_pin);

    x->out = outlet_new(&x->x_obj, &s_float);

    outlet_float(x->out, x->last_value);

    post("gpio_in ready GPIO %d (daemon mode)", x->gpio_pin);

    return (void *)x;
}


// FREE
void gpio_in_free(t_gpio_in *x)
{
    if (!x) return;

    if (x->pi >= 0)
    {
        pigpio_stop(x->pi);
    }
}


// SETUP
void gpio_in_setup(void)
{
    gpio_in_class = class_new(
        gensym("gpio_in"),
        (t_newmethod)gpio_in_new,
        (t_method)gpio_in_free,
        sizeof(t_gpio_in),
        CLASS_DEFAULT,
        A_DEFFLOAT,
        0
    );

    class_addbang(gpio_in_class, gpio_in_bang);

    post("gpio_in loaded (pigpiod_if2 stable version)");
}
