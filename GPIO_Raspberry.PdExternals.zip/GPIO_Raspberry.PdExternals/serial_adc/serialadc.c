#include "m_pd.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>

typedef struct _serialadc {
    t_object x_obj;
    int fd;
    t_outlet *out1;
    t_outlet *out2;
    t_outlet *out3;
    t_clock *clock;
    char buffer[256];
    int buf_pos;
} t_serialadc;

static t_class *serialadc_class;

// ---------------- SERIAL OPEN ----------------
int open_serial(const char *device)
{
    int fd = open(device, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (fd < 0) return -1;

    struct termios tty;
    memset(&tty, 0, sizeof(tty));
    tcgetattr(fd, &tty);

    cfsetispeed(&tty, B115200);
    cfsetospeed(&tty, B115200);

    tty.c_cflag = (CLOCAL | CREAD | CS8);
    tty.c_iflag = 0;
    tty.c_oflag = 0;
    tty.c_lflag = 0;

    tcsetattr(fd, TCSANOW, &tty);

    return fd;
}

// ---------------- PARSE ----------------
void process_line(t_serialadc *x, char *line)
{
    int id, value;

    if (sscanf(line, "%d:%d", &id, &value) == 2) {
        if (id == 1) outlet_float(x->out1, value);
        else if (id == 2) outlet_float(x->out2, value);
        else if (id == 3) outlet_float(x->out3, value);
    }
}

// ---------------- LOOP ----------------
void serialadc_tick(t_serialadc *x)
{
    char buf[64];

    int n = read(x->fd, buf, sizeof(buf));

    if (n <= 0) {
        clock_delay(x->clock, 20);
        return;
    }

    for (int i = 0; i < n; i++) {

        char c = buf[i];

        // només ASCII útil
        if (c < 32 && c != '\n' && c != '\r')
            continue;

        if (x->buf_pos < 255)
            x->buffer[x->buf_pos++] = c;

        if (c == '\n' || c == '\r') {

            x->buffer[x->buf_pos] = '\0';

            process_line(x, x->buffer);

            x->buf_pos = 0;
        }
    }

    clock_delay(x->clock, 20);
}

// ---------------- NEW ----------------
void *serialadc_new(void)
{
    t_serialadc *x = (t_serialadc *)pd_new(serialadc_class);

    x->fd = open_serial("/dev/serial0");
    x->buf_pos = 0;

    x->out1 = outlet_new(&x->x_obj, &s_float);
    x->out2 = outlet_new(&x->x_obj, &s_float);
    x->out3 = outlet_new(&x->x_obj, &s_float);

    x->clock = clock_new(x, (t_method)serialadc_tick);
    clock_delay(x->clock, 20);

    return (void *)x;
}

// ---------------- FREE ----------------
void serialadc_free(t_serialadc *x)
{
    if (x->fd > 0) close(x->fd);
    if (x->clock) clock_free(x->clock);
}

// ---------------- SETUP ----------------
void serialadc_setup(void)
{
    serialadc_class = class_new(
        gensym("serialadc"),
        (t_newmethod)serialadc_new,
        (t_method)serialadc_free,
        sizeof(t_serialadc),
        CLASS_DEFAULT,
        0
    );
}
