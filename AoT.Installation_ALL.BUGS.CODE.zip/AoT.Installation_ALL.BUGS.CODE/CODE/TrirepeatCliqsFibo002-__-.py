#microbeats005
#-___________-
from machine import Pin, PWM
import machine
import _thread
import time
import random
#-____________# declare sonic vars__________________________
buzzer = PWM(Pin(12)) #, freq=440, duty=512)
incA = 0.1
#tempo = (random.randint(2,5)*0.0625)
#tempo = 0.125  tempo = 0.125  // 0.0625 // 0.03125 // 0.015625
tempo1= ((random.randint(3,8)*0.03125))
tempo2 = ((random.randint(2,5)*0.0625))
tempo3 = ((random.randint(1,3)*0.125))
#-____________# declare pins for leds & sensor__________________________
led = PWM(Pin(6)) #led = PWM(Pin(25)) 25: internal led
sensor_temp = machine.ADC(4)
conversion_factor = 3.3 / (65535)
reading = sensor_temp.read_u16() * conversion_factor   
temperature = 27 - (reading - 0.706)/0.001721
temper = (temperature)*0.34
#-____________function__________________________
i = -1
while(True):
    for i in range(1 * 3):      
        print(temperature)
        if i < 1:
            buzzer.deinit()
            buzzer.freq(int(temper)*2)
            buzzer.duty_u16(128*21)
            led.duty_u16(64*64)
            time.sleep(tempo2)
            print(i)
        elif i >= 1:
            buzzer.deinit()
            buzzer.freq(11)
            buzzer.duty_u16(0)
            led.duty_u16(0)
            time.sleep(1*tempo2)
            print(i)     
    time.sleep(0)
    #-__________
    for i in range(1 * 5):
        print(temperature)
        if i < 1:
            buzzer.deinit()
            buzzer.freq(int(temper)*3)
            buzzer.duty_u16(128*21)
            led.duty_u16(128*128)
            time.sleep(tempo2)
            print(i)
        elif i >= 1:
            buzzer.deinit()
            buzzer.freq(11)
            buzzer.duty_u16(0)
            led.duty_u16(0)
            time.sleep(3*tempo2)
            print(i)      
    time.sleep(0)
    #-__________

#-__________
    time.sleep((random.randint(3,8)*1))
        #-__________
    for i in range(1 * 2):
        print(temperature)
        if i < 1:
            buzzer.deinit()
            buzzer.freq(int(temper)*2)
            buzzer.duty_u16(128*21)
            led.duty_u16(192*192)
            time.sleep(tempo2)
            print(i)
        elif i >= 1:
            buzzer.deinit()
            buzzer.freq(11)
            buzzer.duty_u16(0)
            led.duty_u16(0)
            time.sleep(5*tempo2)
            print(i)      
    time.sleep(0)
    #-__________
#-__________
    time.sleep((random.randint(3,8)*2))
#-__________
    time.sleep((random.randint(3,8)*3))






