#-___________-  /////////////////////////////blinks&cliqs_by @xamanza___
from machine import Pin, PWM, ADC
import machine
import time
import random
#-____________/////////////// Setup__________________________

buzzer = PWM(Pin(12))
led = PWM(Pin(6))
led.freq(1000)  # freq fixa per al LED
sensor_temp = ADC(4)
conversion_factor = 3.3 / (65535)

#-____________///////////////Funcions d'ajuda__________________________

def get_temperature():
    reading = sensor_temp.read_u16() * conversion_factor   
    temperature = 27 - (reading - 0.706)/0.001721
    return temperature * 0.34

def beep(freq, dur, led_duty=32768, buzzer_duty=1024):
    buzzer.freq((random.randint(3,8)*3)+16 )
    buzzer.duty_u16(random.randint(1,8)*buzzer_duty)
    led.duty_u16(random.randint(3,34)* 1024 )
    time.sleep(dur)
    buzzer.duty_u16(0)
    led.duty_u16(0)
    
#____led.duty_u16 valor va de 0 a 65535 (16 bits)

#-____________///////////////Sequences
def fase1():
    tempo = random.randint(1,3)*0.125
    for i in range(3):
        t = get_temperature()
        if i < 1:
            beep(int(t)*2, tempo)
            led.duty_u16(random.randint(3,34)* 1024 )
        else:
            time.sleep(tempo)
            led.duty_u16(0)
#-____________///////////////Sequences
def fase2():
    tempo = random.randint(2,5)*0.0625
    for i in range(5):
        t = get_temperature()
        if i < 1:
            beep(int(t)*3, tempo)
            led.duty_u16(random.randint(3,34)* 1024 )
        else:
            time.sleep(2*tempo)
            led.duty_u16(0)
#-____________///////////////Sequences
def fase3():
    tempo = random.randint(3,8)*0.03125
    for i in range(8):
        t = get_temperature()
        if i % 2 == 0:
            beep(int(t)*4, tempo)
            led.duty_u16(random.randint(3,34)* 1024 )
        else:
            time.sleep(3*tempo)
            led.duty_u16(0)

#-____________/////////////// Narrativ__________________________
# Loop main + pauses de segons +  pausa cada 3mins
start_time = time.ticks_ms()
while True:
    fase1()
    fase2()
    fase3()
# cada certs segons fem "pauses petites"
    #time.sleep(random.randint(21,55))
    pausaloop = random.randint(21,55)
    print("pausaloop de", pausaloop, "s.")
    time.sleep(pausaloop)
    led.duty_u16(0)
# comprovem si han passat 3mins
    elapsed = time.ticks_diff(time.ticks_ms(), start_time)
    if elapsed >= 180 * 1000:   # 3mins en ms
        buzzer.duty_u16(0)
        led.duty_u16(0)
        #time.sleep(3 * 60)      # 3 minuts
        pausa = random.randint(1,3) * 60
        print("pausa de", pausa, "s.")
        time.sleep(pausa)
        start_time = time.ticks_ms()  # reiniciem comptador
        
        



