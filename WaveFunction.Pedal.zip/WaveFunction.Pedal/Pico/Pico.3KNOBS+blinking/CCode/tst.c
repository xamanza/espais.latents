#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "hardware/adc.h"
#include "hardware/gpio.h"

#define UART_ID uart0
#define BAUD_RATE 115200

#define UART_TX_PIN 0
#define UART_RX_PIN 1

#define LED_PIN 25

// LED states
#define LED_FAST 200
#define LED_SLOW 2000

static absolute_time_t last_led_toggle;
static bool led_state = false;

static int mode = 0; // 0 = fast, 1 = slow, 2 = on, 3 = off

void set_led_mode(int m) {
    mode = m;
}

void led_task() {

    int interval = LED_SLOW;

    if (mode == 0) interval = LED_FAST;
    else if (mode == 1) interval = LED_SLOW;
    else if (mode == 2) {
        gpio_put(LED_PIN, 1);
        return;
    }
    else if (mode == 3) {
        gpio_put(LED_PIN, 0);
        return;
    }

    if (absolute_time_diff_us(last_led_toggle, get_absolute_time()) > interval * 1000) {
        led_state = !led_state;
        gpio_put(LED_PIN, led_state);
        last_led_toggle = get_absolute_time();
    }
}

int read_adc(int channel) {
    adc_select_input(channel);
    return adc_read();
}

void send_knobs() {

    int k1 = read_adc(0); // GP26
    int k2 = read_adc(1); // GP27
    int k3 = read_adc(2); // GP28

    char buf[64];

    sprintf(buf, "1:%d\n", k1);
    uart_puts(UART_ID, buf);

    sprintf(buf, "2:%d\n", k2);
    uart_puts(UART_ID, buf);

    sprintf(buf, "3:%d\n", k3);
    uart_puts(UART_ID, buf);

    set_led_mode(0); // streaming fast
}

int main() {

    uart_init(UART_ID, BAUD_RATE);

    gpio_set_function(UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(UART_RX_PIN, GPIO_FUNC_UART);

    uart_set_format(UART_ID, 8, 1, UART_PARITY_NONE);
    uart_set_fifo_enabled(UART_ID, false);

    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);

    adc_init();
    adc_gpio_init(26);
    adc_gpio_init(27);
    adc_gpio_init(28);

    sleep_ms(1000);

    last_led_toggle = get_absolute_time();

    while (1) {

        send_knobs();
        led_task();

        sleep_ms(50);
    }
}
