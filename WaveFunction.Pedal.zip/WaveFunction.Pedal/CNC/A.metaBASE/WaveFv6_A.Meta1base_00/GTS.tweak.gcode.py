#!/usr/bin/env python3
import sys

INPUT_FILE  = "raw_from_svg.nc"
OUTPUT_FILE = "2Kut.nc"

Z_SAFE    = float(sys.argv[1])
Z_CUT     = float(sys.argv[2])
F_CUT     = float(sys.argv[3])
SPINDLE   = float(sys.argv[4])
STEP_DOWN = float(sys.argv[5])

# ----------------- calcular profunditats -----------------
depths = []
current = -STEP_DOWN
while current > Z_CUT:
    depths.append(current)
    current -= STEP_DOWN
depths.append(Z_CUT)

# ----------------- llegir raw i separar blocs -----------------
blocks = []
current_block = None

with open(INPUT_FILE) as f:
    for line in f:
        line = line.strip()
        if line.startswith("(Block-name:"):
            if current_block:
                blocks.append(current_block)
            current_block = {
                "name": line,
                "moves": [],
                "start": None
            }
        elif line.startswith("G0 X"):
            if current_block and current_block["start"] is None:
                current_block["start"] = line
        elif line.startswith("G1 X"):
            if current_block:
                current_block["moves"].append(line)

    if current_block:
        blocks.append(current_block)

# ----------------- escriure G-code final -----------------
with open(OUTPUT_FILE, "w") as fout:

    # header
    fout.write(";_____________________\n")
    fout.write("; CNC-_-Kut\n")
    fout.write(";_____________________\n")
    fout.write("G21\n")
    fout.write("G90\n")
    fout.write(f"G0 Z{Z_SAFE}\n")
    fout.write(f"M3 S{SPINDLE}\n")
    fout.write("G4 P3\n")

    # blocs
    for block in blocks:
        fout.write(f"\n{block['name']}\n")

        start = block["start"]
        moves = block["moves"]

        if not start or not moves:
            continue

        for depth in depths:
            fout.write(f"G0 Z{Z_SAFE}\n")
            fout.write(start + "\n")
            fout.write(f"G1 Z{depth} F{F_CUT}\n")

            for m in moves:
                fout.write(m + "\n")

            fout.write(f"G0 Z{Z_SAFE}\n")

    # footer
    fout.write("\nM5\n")
    fout.write("G0 X0 Y0\n")

print(f"✔ G-code final amb multipass generat: {OUTPUT_FILE}")
