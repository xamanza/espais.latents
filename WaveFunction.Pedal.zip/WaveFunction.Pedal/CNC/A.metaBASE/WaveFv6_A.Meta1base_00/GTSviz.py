#!/usr/bin/env python3
import sys
import matplotlib.pyplot as plt

# ---------------- CONFIG ----------------
INPUT_FILE = "2Kut.nc"

Z_SAFE = float(sys.argv[1])
Z_CUT = float(sys.argv[2])

#TABLE_WIDTH  = 400
#TABLE_HEIGHT = 400
#MIRROR_Y     = True

# ---------------- Preparar llistes ----------------
x_coords = []
y_coords = []
colors   = []

current_z = Z_SAFE
last_x = None
last_y = None

# ---------------- Llegir G-code ----------------
with open(INPUT_FILE) as f:
    for line in f:
        line = line.strip()
        if line.startswith("G0") or line.startswith("G1"):
            parts = line.split()
            x = y = z = None
            for p in parts:
                if p.startswith("X"):
                    x = float(p[1:])
                elif p.startswith("Y"):
                    y = float(p[1:])
                elif p.startswith("Z"):
                    z = float(p[1:])
            if z is not None:
                current_z = z
            if x is not None or y is not None:
                # si alguna coordenada falta, manté la anterior
                if x is None: x = last_x
                if y is None: y = last_y
                if last_x is not None and last_y is not None:
                    # afegir línia al plot
                    x_coords.append([last_x, x])
                    y_coords.append([last_y, y])
                    # assignar color
                    if current_z <= Z_CUT:
                        colors.append("#008080")  # tall
                    else:
                        colors.append("#FFD42A")  # Z safe
                last_x, last_y = x, y

# -------------------- PLOT --------------------
fig, ax = plt.subplots(figsize=(8,8), dpi=96)  # 800x800 px
ax.set_facecolor("#000000")
for xs, ys, c in zip(x_coords, y_coords, colors):
    ax.plot(xs, ys, color=c, linewidth=1)

# centrat al mig del 400x400 mm
#ax.set_xlim(-TABLE_WIDTH/2, TABLE_WIDTH/2)
#ax.set_ylim(-TABLE_HEIGHT/2, TABLE_HEIGHT/2)
ax.set_xlim(-200, 200)
ax.set_ylim(-200, 200)
ax.set_aspect('equal')
ax.set_title("G-code Preview", color="white")
ax.tick_params(colors='white')

# opcional: veure punts llegits (debug)
#print(f"Total línies llegides: {len(x_coords)}")

plt.show()

