# terminal > run >  python3 GTS.py
#!/usr/bin/env python3
import subprocess
import sys

# ---------------- CONFIG CENTRAL ----------------
SVG_FILE  = "vector2kut.svg"
RAW_NC  = "raw_from_svg.nc"
FINAL_NC  = "2Kut.nc"
# ---  Z center 0,0  >>> tocar material ipujar 10units offline  //// Exemple material  4mm MDF  >>   Zkut      -14   /////   spindl   800  /////  Fcut       200
# actual params mdf 10mm
Z_SAFE  = 20
Z_CUT  = -12  #mm deep kut
F_CUT  = 320 # velocitat de tall > lent evita cremar mdf 150--200mm/min  # Metacrilat i Acrilic  entre 250  i 450 rpms
SPINDLE  = 600  # MDF entre 500 i 1000 rpms  # Metacrilat i Acrilic  entre 500 i 700 rpms
STEP_DOWN  = 1.5     # mm per passades múltiples

# ---------------- FUNCIONS ----------------
def run_script(script, args=[]):
    cmd = [sys.executable, script] + args
    print(f"\n--- Executant {script} ---")
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print(f"⚠ Error en {script}")
        sys.exit(1)

# ---------------- PIPELINE ----------------
# 1️⃣ SVG -> G-code raw
run_script("svg2gcode.py", [
    str(Z_SAFE),
    str(Z_CUT),
    str(F_CUT),
    str(SPINDLE),
    str(STEP_DOWN)
])

# 2️⃣ Raw G-code -> GTS tweak
run_script("GTS.tweak.gcode.py", [
    str(Z_SAFE),
    str(Z_CUT),
    str(F_CUT),
    str(SPINDLE),
    str(STEP_DOWN)
])

# 3️⃣ Mostrar preview
run_script("GTSviz.py", [
    str(Z_SAFE),
    str(Z_CUT)
])

print("\n✔ Pipeline complet executat amb èxit!")
