#!/bin/bash
sleep 10
pd /home/wavefunction/Desktop/wavefunction.pd
