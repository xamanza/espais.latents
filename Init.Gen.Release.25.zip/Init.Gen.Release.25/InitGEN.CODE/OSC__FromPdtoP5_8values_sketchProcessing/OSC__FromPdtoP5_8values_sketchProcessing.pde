//code by @xamanza 2023 // metapatterns OSC collector
import oscP5.*;
import netP5.*;

OscP5 oscP5;
int port;
float i1;
float i2;
float i3;
float i4;
float i5;
float i6;
float i7;
float i8;

float posX1, posY1, diametre1;
float posX2, posY2, diametre2;
float posX3, posY3, diametre3;
float posX4, posY4, diametre4;
float posX5, posY5, diametre5;
float posX6, posY6, diametre6;
float posX7, posY7, diametre7;
float posX8, posY8, diametre8;


void setup() {
  size(768, 768);
  //size(512, 512);
  background(255);
//
  posX1 = width / 4;
  posX2 = width / 2;
  posX3 = 3 * width / 4;
  posX4 = 2 * width / 4;
  posX5 = width / 3;
  posX6 = width / 2;
  posX7 = 3 * width / 5;
  posX8 = 2 * width / 8;

//
  posY1 = height / 4;
  posY2 = height / 2;
  posY3 = height / 1;
  posY4 = height / 1;
  posY5 = height / 8;
  posY6 = height / 2.5;
  posY7 = height / 3;
  posY8 = height / 5;

//
  diametre1 = 55;
  diametre2 = 34;
  diametre3 = 89;
  diametre4 = 144;
  diametre5 = 21;
  diametre6 = 89;
  diametre7 = 89;
  diametre8 = 21;

//
  port = 11111; //////////////! edit port
  oscP5 = new OscP5(this, port);
}

void draw() {
  background(0);  
  // Draw ellipse for i1
  noStroke();
  fill(215, 152, 16, i1*144);
  ellipse(posX1, posY1, diametre1, diametre1);
  //
  // Draw ellipse for i2
  fill(144, 144, 187, i2*180);
  ellipse(posX2, posY2, diametre2, diametre2);
  //
  // Draw ellipse for i3
  fill(234, 55, 89, i3*155);
  ellipse(posX3, posY3, diametre3, diametre3);
    //
      // Draw ellipse for i4
  fill(234, 55, 23, i4*174);
  ellipse(posX4, posY4, diametre4, diametre4);
    //
  // Draw ellipse for i5
  noStroke();
  fill(189, 89, 27, i5*189);
  ellipse(posX5, posY5, diametre5, diametre5);
  //
  // Draw ellipse for i6
  fill(89, 144, 234, i6*166);
  ellipse(posX6, posY6, diametre6, diametre6);
  //
  // Draw ellipse for i7
  fill(89, 55, 89, i7*189);
  ellipse(posX7, posY7, diametre7, diametre7);
    //
      // Draw ellipse for i8
  fill(189, 144, 23, i8*144);
  ellipse(posX8, posY8, diametre8, diametre8);
    //


}

void oscEvent(OscMessage theOscMessage) {
  if (theOscMessage.checkAddrPattern("/i1") && theOscMessage.checkTypetag("f")) {
    i1 = theOscMessage.get(0).floatValue();  //////////////! i1 is the OSC's ID from pd 1st value to send
    posY1 = int(map(i1*4, 14, 34, height, 0));
    diametre1 = int(map(i1, 34, 100, height, 0));
    println("i1: " + i1);
  }
//
  if (theOscMessage.checkAddrPattern("/i2") && theOscMessage.checkTypetag("f")) {
    i2 = theOscMessage.get(0).floatValue(); //////////////! i2 is the OSC's ID from pd 2nd value to send
    posY2 = int(map(i2*23, 134, 89, height, 0));
    diametre2 = int(map(i2, 69, 87, height, 9));
    println("i2: " + i2);
  }
//
  if (theOscMessage.checkAddrPattern("/i3") && theOscMessage.checkTypetag("f")) {
    i3 = theOscMessage.get(0).floatValue(); //////////////! i3 is the OSC's ID from pd 3st value to send
    posY3 = int(map(i3*46, 136, 77, height, 0));
    diametre3 = int(map(i3, 54, 89, height, 0));
    println("i3: " + i3);
  }
//
  if (theOscMessage.checkAddrPattern("/i4") && theOscMessage.checkTypetag("f")) {
    i4 = theOscMessage.get(0).floatValue(); //////////////! i4 is the OSC's ID from pd 3st value to send
    posY4 = int(map(i4*46, 136, 77, height, 0));
    diametre4 = int(map(i4, 54, 89, height, 0));
    println("i4: " + i4);
  }
  
    if (theOscMessage.checkAddrPattern("/i5") && theOscMessage.checkTypetag("f")) {
    i5 = theOscMessage.get(0).floatValue();  //////////////! i1 is the OSC's ID from pd 1st value to send
    posY5 = int(map(i5*4, 14, 34, height, 0));
    diametre5 = int(map(i5, 34, 89, height, 0));
    println("i5: " + i5);
  }
//
  if (theOscMessage.checkAddrPattern("/i6") && theOscMessage.checkTypetag("f")) {
    i6 = theOscMessage.get(0).floatValue(); //////////////! i2 is the OSC's ID from pd 2nd value to send
    posY6 = int(map(i6*23, 134, 89, height, 0));
    diametre6 = int(map(i6, 69, 89, height, 9));
    println("i6: " + i6);
  }
//
  if (theOscMessage.checkAddrPattern("/i7") && theOscMessage.checkTypetag("f")) {
    i7 = theOscMessage.get(0).floatValue(); //////////////! i3 is the OSC's ID from pd 3st value to send
    posY7 = int(map(i7*46, 136, 77, height, 0));
    diametre7 = int(map(i7, 54, 89, height, 0));
    println("i7: " + i7);
  }
//
  if (theOscMessage.checkAddrPattern("/i8") && theOscMessage.checkTypetag("f")) {
    i8 = theOscMessage.get(0).floatValue(); //////////////! i4 is the OSC's ID from pd 3st value to send
    posY8 = int(map(i8*46, 136, 77, height, 0));
    diametre8 = int(map(i8, 54, 89, height, 0));
    println("i8: " + i8);
  }
//end
}
