#!/usr/bin/env python3
import sys
from svgpathtools import svg2paths2, Path, Line, CubicBezier, QuadraticBezier, Arc
import math

# -------------------- PARÀMETRES CLI --------------------
INPUT_SVG  = "vector2kut.svg"
OUTPUT_FILE = "raw_from_svg.nc"

Z_SAFE  = float(sys.argv[1])
Z_CUT  = float(sys.argv[2])
F_CUT  = float(sys.argv[3])
SPINDLE  = float(sys.argv[4])
#STEP_DOWN  = float(sys.argv[5])

# Opcions de discretització i centrament
STEP_MM    = 0.5    # pas per aproximar corbes
DECIMALS   = 3      # decimals per coordenades
TABLE_WIDTH  = 400
TABLE_HEIGHT = 400
MIRROR_Y     = True



# -------------------- FUNCIONS AUX --------------------
def discretize_segment(seg, step=STEP_MM):
    length = seg.length()
    num_points = max(int(math.ceil(length / step)), 1)
    points = [seg.point(t) for t in [i/num_points for i in range(num_points+1)]]
    return [(round(p.real, DECIMALS), round(p.imag, DECIMALS)) for p in points]

def discretize_subpath(subpath, step=STEP_MM):
    points = []
    for seg in subpath:
        points.extend(discretize_segment(seg, step))
    return points

# -------------------- LLEGIR SVG --------------------
paths, attributes, svg_att = svg2paths2(INPUT_SVG)

# Centre de la taula CNC
center_x = TABLE_WIDTH / 2
center_y = TABLE_HEIGHT / 2

# -------------------- ESCRIURE G-CODE --------------------
with open(OUTPUT_FILE, "w") as f:
    block_count = 1

    for path in paths:
        # Separar subpaths quan hi ha moviments M
        subpaths = []
        current_sub = Path()
        for seg in path:
            if len(current_sub) > 0 and seg.start != current_sub[-1].end:
                subpaths.append(current_sub)
                current_sub = Path()
            current_sub.append(seg)
        if len(current_sub) > 0:
            subpaths.append(current_sub)

        # Cada subpath és un bloc
        for sub in subpaths:
            points = discretize_subpath(sub)
            if not points:
                continue

            f.write(f"(Block-name: SVG_Block_{block_count})\n")
            f.write(f"G0 Z{Z_SAFE}\n")

            started = False
            for x, y in points:
                # Centrat al 0,0 del CNC
                x = x - center_x
                y = y - center_y
                if MIRROR_Y:
                    y = -y

                if not started:
                    f.write(f"G0 X{x} Y{y}\n")        # primer punt
                    f.write(f"G1 Z{Z_CUT} F{F_CUT}\n") # baixar fresa
                    started = True
                else:
                    f.write(f"G1 X{x} Y{y}\n")        # moviments següents

            f.write(f"G0 Z{Z_SAFE}\n")  # aixecar al final
            block_count += 1

print(f"✔ G-code raw generat: {OUTPUT_FILE}")

# //////////// developed by @xamanza with TRansformer assistance 2026 / GPL 
